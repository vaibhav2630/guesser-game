import java.util.Scanner;
class guesserR3
{
    int gsarr[]=new int[4];
    int[] gussingno()
    {
        for(int i=0;i<4;i++)
        {
            Scanner s=new Scanner(System.in);
            System.out.println("guesser  guess value for position"+i);
            gsarr[i]=s.nextInt();
        }
        return gsarr;

    }

}
class player1R3
{
    int p1arr[]=new int[4];
    int[] gussingno()
    {
        for(int i=0;i<4;i++)
        {
            Scanner s=new Scanner(System.in);
            System.out.println("guesser  guess value for position"+i);
            p1arr[i]=s.nextInt();
        }
        return p1arr;

    }

}
class player2R3
{
    int p2arr[]=new int[4];
    int[] gussingno()
    {
        for(int i=0;i<4;i++)
        {
            Scanner s=new Scanner(System.in);
            System.out.println("player 2  guess value for position"+i);
            p2arr[i]=s.nextInt();
        }
        return p2arr;

    }

}

class player3R3
{
    int p3arr[]=new int[4];
    int[] gussingno()
    {
        for(int i=0;i<4;i++)
        {
            Scanner s=new Scanner(System.in);
            System.out.println("player3  guess value for position"+i);
            p3arr[i]=s.nextInt();
        }
        return p3arr;

    }


}
class scorerR3
{
    int guesserR3[]=new int[4];
    int player1R3[]=new int[4];
    int player2R3[]=new int[4];
    int player3R3[]=new int[4];
    int count1=0;
    int count2=0;
    int count3=0;
    void getGuesserR3()
    {
        guesserR3 obj=new guesserR3();
        guesserR3=obj.gussingno();

    }
    void getplayer1R3()
    {
        player1R3 obj=new player1R3();
        player1R3=obj.gussingno();
    }
    void getplayer2R3()
    {
        player2R3 obj=new player2R3();
        player2R3=obj.gussingno();
    }
    void getplayer3R3()
    {
        player3R3 obj=new player3R3();
        player3R3=obj.gussingno();
    }
    int getScorep1()
    {
        for(int i=0;i<4;i++)
        {
            if(guesserR3==player1R3)
            {
                count1=count1+1;
            }
        }
        return count1;
    }
    int getScorep2()
    {
        for(int i=0;i<4;i++)
        {
            if(guesserR3==player2R3)
            {
                count2=count2+1;
            }
        }
        return count2;
    }
    int getScorep3()
    {
        for(int i=0;i<4;i++)
        {
            if(guesserR3==player3R3)
            {
                count3=count3+1;
            }
        }
        return count3;
    }
    
    
}
class umpireR3
{
    int player1;
    int player2;
    int player3;
    void getCount1R3()
    {
        scorerR3 obj= new scorerR3();
        player1=obj.getScorep1();
        
    }
    void getCount2R3()
    {
        scorerR3 obj= new scorerR3();
        player2=obj.getScorep2();
        
    }
    void getCount3R3()
    {
        scorerR3 obj= new scorerR3();
        player3=obj.getScorep3();
        
    }
    void compare()
    {
        if(player3==player2&&player2==player1&&player1==player3)
        {
            System.out.println("game tied");
        }
        else if(player1>player3&&player1>player2)
        {
            System.out.println("player1 won");
        }
        else if(player2>player3&&player2>player1)
        {
            System.out.println("player2 wom");
        }
        else if(player3>player1&&player3>player2)
        {
            System.out.println("player3 won");
        }
        else
        {
            System.out.println("no one won");
        }
        
    }
}
class guesserR2
{
    String num;
    String gussingno()
    {

        Scanner scan=new Scanner(System.in);
        System.out.println("guesser  guess a alphabet.:-");
        num=scan.next();
        return num;


    
    }

}
class player1R2
{
    String num;
    String gussingno()
    {
        Scanner scan=new Scanner(System.in);
        System.out.println("player1  guess a alphabet.:-");
        num=scan.next();
        return num;


    }
}
class player2R2
{
    String num;
    String gussingno()
    {
        Scanner scan=new Scanner(System.in);
        System.out.println("player2 guess a alphabet .:-");
        num=scan.next();
        return num;


    }
}

class player3R2
{
    String num;
    String gussingno()
    {
        Scanner scan=new Scanner(System.in);
        System.out.println("player3 guess a alphabet.:-");
        num=scan.next();
        return num;


    }
}
class umpireR2
{
    String guesser;
    String player1;
    String player2;
    String player3;
    void getGuesserR2()
    {
        guesserR2 obj=new guesserR2();
        guesser=obj.gussingno();

    }
    void getplayer1R2()
    {
        player1R2 obj=new player1R2();
        player1=obj.gussingno();
    }
    void getplayer2R2()
    {
        player2R2 obj=new player2R2();
        player2=obj.gussingno();
    }
    void getplayer3R2()
    {
        player3R2 obj=new player3R2();
        player3=obj.gussingno();
    }
    void tieBreakerR2()
    {
        if(guesser==player1)
        {
            System.out.println("player1 won tie breaker");
        }
        else if(guesser==player2)
        {
            System.out.println("player2 won tie breaker");
            
        }
        else
        {
            System.out.println("player3 won tie breaker");
        }
    }
    
    void compareR2()
    {
        if (guesser.equalsIgnoreCase(player1)&&guesser.equalsIgnoreCase(player2)&&guesser.equalsIgnoreCase(player3))
        {
            System.out.println("all have won game tied");
            System.out.println();
            System.out.println("displaying OPTIONS");
            System.out.println();
            System.out.println("OPTION 1 :- press 0 for exit ");
            System.out.println();
            System.out.println("OPTION 2 :- press 1 for another round in numeric theme");
            System.out.println();
            System.out.println("OPTION 3 :- PRESS 2 for another round in alphabet theme");
            System.out.println();
            int choice=0;
            System.out.println("enter your choice");
            Scanner s= new Scanner(System.in);
            choice=s.nextInt();
            if (choice==0)
            {
                System.out.println("game ended");
                
            }
            else if(choice==1)
            {
                umpire u=new umpire();
                u.getGuesser();
                u.getplayer1();
                u.getplayer2();
                u.getplayer3();
                u.compare();
                
                
            }
            else if(choice==2)
            {
                getGuesserR2();
                getplayer1R2();
                getplayer2R2();
                getplayer3R2();
                compareR2();
            }
            else
            {
                System.out.println("you have entered wrong choise game exited");
            }
        }
        else if(guesser.equalsIgnoreCase(player1)&&guesser.equalsIgnoreCase(player2)||guesser.equalsIgnoreCase(player3)&&guesser.equalsIgnoreCase(player2)||guesser.equalsIgnoreCase(player1)&&guesser.equalsIgnoreCase(player3))
        {
            if(guesser.equalsIgnoreCase(player1)&&guesser.equalsIgnoreCase(player2))
            {
                System.out.println("player2&player1 won");
                System.out.println("press 0 for exit or 1 for another tie braker round bwt player1 & player2");
                int choice=0;
                System.out.println("enter your choice");
                Scanner s= new Scanner(System.in);
                choice=s.nextInt();
                if (choice==0)
                {
                    System.out.println("game ended at tie bwt player 1 & player 2");
                
                }
                else if(choice==1)
                {
                    getGuesserR2();
                    getplayer1R2();
                    getplayer2R2();
                    tieBreakerR2();
                }
                else
                {
                    System.out.println("you have entered wrong choise game exited");
                }
            }
            else if(guesser.equalsIgnoreCase(player2)&&guesser.equalsIgnoreCase(player3))
            {
                System.out.println("player3 & player2 won");
                 System.out.println("press 0 for exit or press 1 for another tie braker round bwt player3 & player2");
                int choice=0;
                System.out.println("enter your choice");
                Scanner s= new Scanner(System.in);
                choice=s.nextInt();
                if (choice==0)
                {
                    System.out.println("game ended at tie bwt player 3 & player 2");
                
                }
                else if(choice==1)
                {
                    getGuesserR2();
                    getplayer2R2();
                    getplayer3R2();
                    tieBreakerR2();


                }
                else
                {
                    System.out.println("you have entered wrong choise game exited");
                }
            }
            else
            {
                System.out.println("player1 & player3 won player2 eliminated");
                 System.out.println("press 0 for exit or 1 for another tie braker round bwt player1 & player3");
                int choice=0;
                System.out.println("enter your choice");
                Scanner s= new Scanner(System.in);
                choice=s.nextInt();
                if (choice==0)
                {
                    System.out.println("game ended at tie bwt player 1 & player 3");
                
                }
                else if(choice==1)
                {
                    getGuesserR2();
                    getplayer1R2();
                    getplayer3R2();
                    tieBreakerR2();
                }
                else
                {
                    System.out.println("you have entered wrong choise game exited");
                }
            }
        }
        else if(guesser.equalsIgnoreCase(player1))
        {
            System.out.println("player1 won");
            System.out.println();
            System.out.println("displaying OPTIONS");
            System.out.println();
            System.out.println("OPTION 1 :- press 0 for exit ");
            System.out.println();
            System.out.println("OPTION 2 :- press 1 for another round in numeric theme");
            System.out.println();
            System.out.println("OPTION 3 :- PRESS 2 for another round in alphabet theme");
            System.out.println();
            int choice=0;
            System.out.println("enter your choice");
            Scanner s= new Scanner(System.in);
            choice=s.nextInt();
            if (choice==0)
            {
                System.out.println("game ended");
                
            }
            else if(choice==1)
            {
                umpire u=new umpire();
                u.getGuesser();
                u.getplayer1();
                u.getplayer2();
                u.getplayer3();
                u.compare();
                
                
            }
            else if(choice==2)
            {
                getGuesserR2();
                getplayer1R2();
                getplayer2R2();
                getplayer3R2();
                compareR2();
            }
            else
            {
                System.out.println("you have entered wrong choise game exited");
            }
        }
        else if(guesser.equalsIgnoreCase(player2))
        {
            System.out.println("player2 won");
            System.out.println();
            System.out.println("displaying OPTIONS");
            System.out.println();
            System.out.println("OPTION 1 :- press 0 for exit ");
            System.out.println();
            System.out.println("OPTION 2 :- press 1 for another round in numeric theme");
            System.out.println();
            System.out.println("OPTION 3 :- PRESS 2 for another round in alphabet theme");
            System.out.println();
            int choice=0;
            System.out.println("enter your choice");
            Scanner s= new Scanner(System.in);
            choice=s.nextInt();
            if (choice==0)
            {
                System.out.println("game ended");
                
            }
            else if(choice==1)
            {
                umpire u=new umpire();
                u.getGuesser();
                u.getplayer1();
                u.getplayer2();
                u.getplayer3();
                u.compare();
                
            }
            else if(choice==2)
            {
                getGuesserR2();
                getplayer1R2();
                getplayer2R2();
                getplayer3R2();
                compareR2();
            }
            else
            {
                System.out.println("you have entered wrong choise game exited");
            }
        }
        else if(guesser.equalsIgnoreCase(player3))
        {
            System.out.println("player3 won");
            System.out.println();
            System.out.println("displaying OPTIONS");
            System.out.println();
            System.out.println("OPTION 1 :- press 0 for exit ");
            System.out.println();
            System.out.println("OPTION 2 :- press 1 for another round in numeric theme");
            System.out.println();
            System.out.println("OPTION 3 :- PRESS 2 for another round in alphabet theme");
            System.out.println();
            int choice=0;
            System.out.println("enter your choice");
            Scanner s= new Scanner(System.in);
            choice=s.nextInt();
            if (choice==0)
            {
                System.out.println("game ended");
                
            }
            else if(choice==1)
            {
                umpire u=new umpire();
                u.getGuesser();
                u.getplayer1();
                u.getplayer2();
                u.getplayer3();
                u.compare();
                
            }
            else if(choice==2)
            {
                getGuesserR2();
                getplayer1R2();
                getplayer2R2();
                getplayer3R2();
                compareR2();
            }
            else
            {
                System.out.println("you have entered wrong choise game exited");
            }
        }
        else
        {
            System.out.println("no one won the game");
            System.out.println();
            System.out.println("displaying OPTIONS");
            System.out.println();
            System.out.println("OPTION 1 :- press 0 for exit ");
            System.out.println();
            System.out.println("OPTION 2 :- press 1 for another round in numeric theme");
            System.out.println();
            System.out.println("OPTION 3 :- PRESS 2 for another round in alphabet theme");
            System.out.println();
            int choice=0;
            System.out.println("enter your choice");
            Scanner s= new Scanner(System.in);
            choice=s.nextInt();
            if (choice==0)
            {
                System.out.println("game ended");
                
            }
            else if(choice==1)
            {
                umpire u=new umpire();
                u.getGuesser();
                u.getplayer1();
                u.getplayer2();
                u.getplayer3();
                u.compare();
                
            }
            else if(choice==2)
            {
                getGuesserR2();
                getplayer1R2();
                getplayer2R2();
                getplayer3R2();
                compareR2();
            }
            else
            {
                System.out.println("you have entered wrong choise game exited");
            }
        }
    
    }

}


class guesser
{
    int num;
    int gussingno()
    {
        try
        {
            Scanner scan=new Scanner(System.in);
            System.out.println("guesser guess a number.:-");
            num=scan.nextInt();
            return num;
            
        }
        catch(Exception e)
        {
            System.out.println("guesser YOU ENTERED A CHARACTER please enter a number");
            gussingno();
            return 0;
        }
    
    }

}
class player1
{
    int num;
    int gussingno()
    {
        try
        {
            Scanner scan=new Scanner(System.in);
            System.out.println("player1 guess a number.:-");
            num=scan.nextInt();
            return num;
            
        }
        catch(Exception e)
        {
            System.out.println("player1 YOU ENTERED A CHARACTER please enter a number");
            gussingno();
            return 0;
        }


    }
}
class player2
{
    int num;
    int gussingno()
    {
        try
        {
            Scanner scan=new Scanner(System.in);
            System.out.println("player2 guess a number.:-");
            num=scan.nextInt();
            return num;
            
        }
        catch(Exception e)
        {
            System.out.println("player1 YOU ENTERED A CHARACTER please enter a number");
            gussingno();
            return 0;
        }

    }
}

class player3
{
    int num;
    int gussingno()
    {
        try
        {
            Scanner scan=new Scanner(System.in);
            System.out.println("player3 guess a number.:-");
            num=scan.nextInt();
            return num;
            
        }
        catch(Exception e)
        {
            System.out.println("player1 YOU ENTERED A CHARACTER please enter a number");
            gussingno();
            return 0;
        }
    }

}
class umpire
{
    int guesser;
    int player1;
    int player2;
    int player3;
    void getGuesser()
    {
        guesser obj=new guesser();
        guesser=obj.gussingno();

    }
    void getplayer1()
    {
        player1 obj=new player1();
        player1=obj.gussingno();
    }
    void getplayer2()
    {
        player2 obj=new player2();
        player2=obj.gussingno();
    }
    void getplayer3()
    {
        player3 obj=new player3();
        player3=obj.gussingno();
    }
    void tieBreaker()
    {
        if(guesser==player1)
        {
            System.out.println("player1 won tie breaker");
        }
        else if(guesser==player2)
        {
            System.out.println("player2 won tie breaker");
            
        }
        else
        {
            System.out.println("player3 won tie breaker");
        }
    }
    
    void compare()
    {
        if (guesser==player1&&guesser==player2&&guesser==player3)
        {
            System.out.println("all have won game tied");
            System.out.println();
            System.out.println("displaying OPTIONS");
            System.out.println();
            System.out.println("OPTION 1 :- press 0 for exit ");
            System.out.println();
            System.out.println("OPTION 2 :- press 1 for another round in numeric theme");
            System.out.println();
            System.out.println("OPTION 3 :- PRESS 2 for another round in alphabet theme");
            System.out.println();
            int choice=0;
            System.out.println("enter your choice");
            Scanner s= new Scanner(System.in);
            choice=s.nextInt();
            if (choice==0)
            {
                System.out.println("game ended");
                
            }
            else if(choice==1)
            {
                getGuesser();
                getplayer1();
                getplayer2();
                getplayer3();
                compare();
            }
            else
            {
                System.out.println("you have entered wrong choise game exited");
            }
        }
        else if(guesser==player1&&guesser==player2||guesser==player3&&guesser==player2||guesser==player1&&guesser==player3)
        {
            if(guesser==player1&&guesser==player2)
            {
                System.out.println("player2&player1 won");
                System.out.println("press 0 for exit or 1 for another tie braker round bwt player1 & player2");
                int choice=0;
                System.out.println("enter your choice");
                Scanner s= new Scanner(System.in);
                choice=s.nextInt();
                if (choice==0)
                {
                    System.out.println("game ended at tie bwt player 1 & player 2");
                
                }
                else if(choice==1)
                {
                    getGuesser();
                    getplayer1();
                    getplayer2();
                    tieBreaker();
                }
                else
                {
                    System.out.println("you have entered wrong choise game exited");
                }
            }
            else if(guesser==player2&&guesser==player3)
            {
                System.out.println("player3 & player2 won");
                 System.out.println("press 0 for exit or press 1 for another tie braker round bwt player3 & player2");
                int choice=0;
                System.out.println("enter your choice");
                Scanner s= new Scanner(System.in);
                choice=s.nextInt();
                if (choice==0)
                {
                    System.out.println("game ended at tie bwt player 3 & player 2");
                
                }
                else if(choice==1)
                {
                    getGuesser();
                    getplayer2();
                    getplayer3();
                    tieBreaker();


                }
                else
                {
                    System.out.println("you have entered wrong choise game exited");
                }
            }
            else
            {
                System.out.println("player1 & player3 won player2 eliminated");
                 System.out.println("press 0 for exit or 1 for another tie braker round bwt player1 & player3");
                int choice=0;
                System.out.println("enter your choice");
                Scanner s= new Scanner(System.in);
                choice=s.nextInt();
                if (choice==0)
                {
                    System.out.println("game ended at tie bwt player 1 & player 3");
                
                }
                else if(choice==1)
                {
                    getGuesser();
                    getplayer1();
                    getplayer3();
                    tieBreaker();
                }
                else
                {
                    System.out.println("you have entered wrong choise game exited");
                }
            }
        }
        else if(guesser==player1)
        {
            System.out.println("player1 won");
            System.out.println();
            System.out.println("displaying OPTIONS");
            System.out.println();
            System.out.println("OPTION 1 :- press 0 for exit ");
            System.out.println();
            System.out.println("OPTION 2 :- press 1 for another round in numeric theme");
            System.out.println();
            System.out.println("OPTION 3 :- PRESS 2 for another round in alphabet theme");
            System.out.println();
            int choice=0;
            System.out.println("enter your choice");
            Scanner s= new Scanner(System.in);
            choice=s.nextInt();
            if (choice==0)
            {
                System.out.println("game ended");
                
            }
            else if(choice==1)
            {
                getGuesser();
                getplayer1();
                getplayer2();
                getplayer3();
                compare();
            }
            else
            {
                System.out.println("you have entered wrong choise game exited");
            }
        }
        else if(guesser==player2)
        {
            System.out.println("player2 won");
            System.out.println();
            System.out.println("displaying OPTIONS");
            System.out.println();
            System.out.println("OPTION 1 :- press 0 for exit ");
            System.out.println();
            System.out.println("OPTION 2 :- press 1 for another round in numeric theme");
            System.out.println();
            System.out.println("OPTION 3 :- PRESS 2 for another round in alphabet theme");
            System.out.println();
            int choice=0;
            System.out.println("enter your choice");
            Scanner s= new Scanner(System.in);
            choice=s.nextInt();
            if (choice==0)
            {
                System.out.println("game ended");
                
            }
            else if(choice==2) 
            {
                umpireR2 u1=new umpireR2();
                u1.getGuesserR2();
                u1.getplayer1R2();
                u1.getplayer2R2();
                u1.getplayer3R2();
                u1.compareR2();
                
            }
            else if(choice==1)
            {
                getGuesser();
                getplayer1();
                getplayer2();
                getplayer3();
                compare();
            }
            else
            {
                System.out.println("you have entered wrong choise game exited");
            }
        }
        else if(guesser==player3)
        {
            System.out.println("player3 won");
            System.out.println();
            System.out.println("displaying OPTIONS");
            System.out.println();
            System.out.println("OPTION 1 :- press 0 for exit ");
            System.out.println();
            System.out.println("OPTION 2 :- press 1 for another round in numeric theme");
            System.out.println();
            System.out.println("OPTION 3 :- PRESS 2 for another round in alphabet theme");
            System.out.println();
            int choice=0;
            System.out.println("enter your choice");
            Scanner s= new Scanner(System.in);
            choice=s.nextInt();
            if (choice==0)
            {
                System.out.println("game ended");
                
            }
            else if(choice==1)
            {
                getGuesser();
                getplayer1();
                getplayer2();
                getplayer3();
                compare();
            }
            else
            {
                System.out.println("you have entered wrong choise game exited");
            }
        }
        else
        {
            System.out.println("no one won the game");
              System.out.println("press 0 for exit or 1 for another chance");
            int choice=0;
            System.out.println("enter your choice");
            Scanner s= new Scanner(System.in);
            choice=s.nextInt();
            if (choice==0)
            {
                System.out.println("game ended");
                
            }
            else if(choice==1)
            {
                getGuesser();
                getplayer1();
                getplayer2();
                getplayer3();
                compare();
            }
            else
            {
                System.out.println("you have entered wrong choise game exited");
            }
        }
    
    }
    
}
public class Main {

    static public void main(String[]args)
    {
        int ch;
        System.out.println("game started");
        System.out.println("SELECT GAME THEME");
        System.out.println("PRESS 1 FOR NUMERIC THEME OR PRESS 0 FOR alphabet THEME ");
        Scanner s=new Scanner(System.in);
        ch=s.nextInt();
        String c="1";
        System.out.println(c.getClass().getSimpleName());
        if(ch==1)
        {
            umpire u=new umpire();
            u.getGuesser();
            u.getplayer1();
            u.getplayer2();
            u.getplayer3();
            u.compare();
        }
        else if(ch==0)
        {
            umpireR2 u1=new umpireR2();
            u1.getGuesserR2();
            u1.getplayer1R2();
            u1.getplayer2R2();
            u1.getplayer3R2();
            u1.compareR2();
        
        }
        else if (ch==2)
        {
            scorerR3 sc=new scorerR3();
            sc.getGuesserR3();
            sc.getplayer1R3();
            sc.getplayer2R3();
            sc.getplayer3R3();
            sc.getScorep1();
            sc.getScorep2();
            sc.getScorep3();
            umpireR3 u2=new umpireR3();
            u2.getCount1R3();
            u2.getCount2R3();

        
            
        }
        else
        {
            System.out.println("you have entered a wrong choise");
        }
        
    
        
    }
    
}

